package it.uniroma1.grpcexampleserver;

import io.grpc.stub.StreamObserver;
import it.uniroma1.gRPCExample.AllBooksRequest;
import it.uniroma1.gRPCExample.AllBooksResponse;
import it.uniroma1.gRPCExample.bookDetailsRequest;
import it.uniroma1.gRPCExample.bookDetailsResponse;
import it.uniroma1.gRPCExample.BooksServiceGrpc.BooksServiceImplBase;


public class BooksServiceImpl extends BooksServiceImplBase {

    @Override
    public void allBooks(
      AllBooksRequest request, StreamObserver<AllBooksResponse> responseObserver) {
        System.out.println("... the server has received: " + request);
        
        String listOfBooks = new StringBuilder()
          .append("The book requested is: ")
          .append(request.getListOfBooks())
          .toString();

        AllBooksResponse response = AllBooksResponse.newBuilder()
          .setListBooks(listOfBooks)
          .build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();

    }
    @Override
    public void bookDetails(
     bookDetailsRequest request, StreamObserver<bookDetailsResponse> responseObserver) {

        System.out.println("... the server has received: " + request);
        
        String bookDetails = new StringBuilder()
          .append("The book requested is: ")
          .append(request.getTitle())
          .append(", writteb by ")
          .append(request.getAuthor())
          .append("in ")
          .append(request.getDate())
          .toString();

        bookDetailsResponse response = bookDetailsResponse.newBuilder()
          .setDetails(bookDetails)
          .build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }
}
