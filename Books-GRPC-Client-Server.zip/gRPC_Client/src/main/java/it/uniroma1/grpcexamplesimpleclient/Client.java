package it.uniroma1.grpcexamplesimpleclient;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import it.uniroma1.gRPCExample.AllBooksRequest;
import it.uniroma1.gRPCExample.AllBooksResponse;
import it.uniroma1.gRPCExample.bookDetailsRequest;
import it.uniroma1.gRPCExample.bookDetailsResponse;
import it.uniroma1.gRPCExample.BooksServiceGrpc;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) throws InterruptedException {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 8080)
            .usePlaintext()
            .build();

        BooksServiceGrpc.BooksServiceBlockingStub stub 
          = BooksServiceGrpc.newBlockingStub(channel);
        
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("Enter a valid book id for retrieving a specific Book, or 'list' to retrieve all books. Insert 'q' or 'quit' to exit.");

        String input = myObj.nextLine();  // Read user input
        System.out.println("The command is: " + input);  // Output user input
        while(true){
            if("q".equals(input) || "quit".equals(input)) break;
            else if("001".equals(input)){
                bookDetailsResponse bookDetailsResponse = stub.bookDetails(bookDetailsRequest.newBuilder()
                    .setTitle("abba")
                    .setAuthor("Hamilton")
                    .setDate("1/7/2002")
                    .build());
                System.out.println("Response received from server:\n" + bookDetailsResponse);
            }else if("002".equals(input)){
                bookDetailsResponse bookDetailsResponse = stub.bookDetails(bookDetailsRequest.newBuilder()
                    .setTitle("babba")
                    .setAuthor("Hamilton")
                    .setDate("2/7/2002")
                    .build());
                System.out.println("Response received from server:\n" + bookDetailsResponse);
            }else if("003".equals(input)){
                bookDetailsResponse bookDetailsResponse = stub.bookDetails(bookDetailsRequest.newBuilder()
                    .setTitle("acca")
                    .setAuthor("Hamilton")
                    .setDate("3/7/2002")
                    .build());
                System.out.println("Response received from server:\n" + bookDetailsResponse);
            }else if("004".equals(input)){
                bookDetailsResponse bookDetailsResponse = stub.bookDetails(bookDetailsRequest.newBuilder()
                    .setTitle("adda")
                    .setAuthor("Hamilton")
                    .setDate("4/7/2002")
                    .build());
                System.out.println("Response received from server:\n" + bookDetailsResponse);
            }else if("005".equals(input)){
                bookDetailsResponse bookDetailsResponse = stub.bookDetails(bookDetailsRequest.newBuilder()
                    .setTitle("dadda")
                    .setAuthor("Hamilton")
                    .setDate("5/7/2002")
                    .build());
                System.out.println("Response received from server:\n" + bookDetailsResponse);
            }else if("006".equals(input)){
                bookDetailsResponse bookDetailsResponse = stub.bookDetails(bookDetailsRequest.newBuilder()
                    .setTitle("qwwe")
                    .setAuthor("Hamilton")
                    .setDate("6/7/2002")
                    .build());
                System.out.println("Response received from server:\n" + bookDetailsResponse);
            }else if("007".equals(input)){
                bookDetailsResponse bookDetailsResponse = stub.bookDetails(bookDetailsRequest.newBuilder()
                    .setTitle("ewwq")
                    .setAuthor("Hamilton")
                    .setDate("7/7/2002")
                    .build());
                System.out.println("Response received from server:\n" + bookDetailsResponse);
            }else if("008".equals(input)){
                bookDetailsResponse bookDetailsResponse = stub.bookDetails(bookDetailsRequest.newBuilder()
                    .setTitle("eew")
                    .setAuthor("Hamilton")
                    .setDate("8/7/2002")
                    .build());
                System.out.println("Response received from server:\n" + bookDetailsResponse);
            }else if("009".equals(input)){
                bookDetailsResponse bookDetailsResponse = stub.bookDetails(bookDetailsRequest.newBuilder()
                    .setTitle("wwe")
                    .setAuthor("Hamilton")
                    .setDate("9/7/2002")
                    .build());
                System.out.println("Response received from server:\n" + bookDetailsResponse);
            }else if("010".equals(input)){
                bookDetailsResponse bookDetailsResponse = stub.bookDetails(bookDetailsRequest.newBuilder()
                    .setTitle("rttr")
                    .setAuthor("Hamilton")
                    .setDate("10/7/2002")
                    .build());
                System.out.println("Response received from server:\n" + bookDetailsResponse);
            }else if("list".equals(input)){
                AllBooksResponse allBooksResponse = stub.allBooks(AllBooksRequest.newBuilder()
                    .setListOfBooks("[001, 002, 003, 004, 005, 006, 007, 008, 009, 010]")
                    .build());
                System.out.println("Response received from server:\n" + allBooksResponse);
            }
            
            System.out.println("Enter a valid book id for retrieving a specific Book, or 'list' to retrieve all books. Insert 'q' or 'quit' to exit.");
            input = myObj.nextLine();  // Read user input
            System.out.println("The command is: " + input);  // Output user input
        }
        
        System.out.println("Closing the channel.\n" );
        channel.shutdown();
    }
}
